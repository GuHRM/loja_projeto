package com.unifucamp.gerencia.controllers;

import com.unifucamp.gerencia.dto.RequisicaoNovoProduto;
import com.unifucamp.gerencia.models.Produto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

import com.unifucamp.gerencia.repositories.ProdutosRepository;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;


@Controller
public class ProdutosController {
    @Autowired
    private ProdutosRepository produtosRepository;
    // Endpoint para retornar todos os produtos
    @GetMapping
    public List<Produto> getAllProdutos() {
        return produtosRepository.findAll();
    }
/* 
    public ProdutosController(ProdutosRepository produtosRepository){
        this.produtosRepository = produtosRepository;
    }
*/
    @GetMapping("/produtos")
    public ModelAndView index() {
        List<Produto> lista_produtos = this.getAllProdutos();
        ModelAndView mv = new ModelAndView("produtos/index");
        mv.addObject("produtos", lista_produtos);
        return mv;
    }
    @GetMapping("/produtos/novo")
    public String prod_new() {
        return "produtos/novo";
    }
    
    @PostMapping("/produtos")
    public String criar(RequisicaoNovoProduto requisicao) {
        Produto produto = requisicao.toProduto();
        this.produtosRepository.save(produto);
        return "redirect:/produtos";
    }
       
}
