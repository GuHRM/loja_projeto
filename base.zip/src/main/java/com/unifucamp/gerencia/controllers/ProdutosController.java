package com.unifucamp.gerencia.controllers;

import com.unifucamp.gerencia.models.Produto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

import com.unifucamp.gerencia.repositories.ProdutosRepository;
@Controller
public class ProdutosController {
    @Autowired
    private ProdutosRepository produtosRepository;
    // Endpoint para retornar todos os produtos
    @GetMapping
    public List<Produto> getAllProdutos() {
        return produtosRepository.findAll();
    }
/* 
    public ProdutosController(ProdutosRepository produtosRepository){
        this.produtosRepository = produtosRepository;
    }
*/
    @GetMapping("/produtos")
    public ModelAndView index() {
        List<Produto> produtos = this.getAllProdutos();
        ModelAndView mv = new ModelAndView("produtos/index");
        mv.addObject("produtos", produtos);
        return mv;
    }
       
}
