package com.unifucamp.gerencia.models;

public class Funcionarios {
    
}
