package com.unifucamp.gerencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
